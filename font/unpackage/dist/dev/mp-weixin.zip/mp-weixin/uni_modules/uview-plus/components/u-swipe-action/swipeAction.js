"use strict";
const SwipeAction = {
  // swipe-action组件
  swipeAction: {
    autoClose: true
  }
};
exports.SwipeAction = SwipeAction;
