"use strict";
const Toolbar = {
  // toolbar 组件
  toolbar: {
    show: true,
    cancelText: "取消",
    confirmText: "确认",
    cancelColor: "#909193",
    confirmColor: "#3c9cff",
    title: ""
  }
};
exports.Toolbar = Toolbar;
