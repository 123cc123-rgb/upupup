"use strict";
const NumberKeyboard = {
  // 数字键盘
  numberKeyboard: {
    mode: "number",
    dotDisabled: false,
    random: false
  }
};
exports.NumberKeyboard = NumberKeyboard;
