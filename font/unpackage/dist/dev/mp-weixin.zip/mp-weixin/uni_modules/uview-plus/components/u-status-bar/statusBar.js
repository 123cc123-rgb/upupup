"use strict";
const StatusBar = {
  // statusBar
  statusBar: {
    bgColor: "transparent"
  }
};
exports.StatusBar = StatusBar;
