"use strict";
const TabbarItem = {
  //
  tabbarItem: {
    name: null,
    icon: "",
    badge: null,
    dot: false,
    text: "",
    badgeStyle: "top: 6px;right:2px;"
  }
};
exports.TabbarItem = TabbarItem;
