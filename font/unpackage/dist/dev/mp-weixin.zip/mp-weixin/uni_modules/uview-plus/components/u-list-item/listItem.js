"use strict";
const ListItem = {
  // listItem 组件
  listItem: {
    anchor: ""
  }
};
exports.ListItem = ListItem;
