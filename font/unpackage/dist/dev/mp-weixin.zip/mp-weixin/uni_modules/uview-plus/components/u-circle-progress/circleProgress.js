"use strict";
const CircleProgress = {
  // circleProgress 组件
  circleProgress: {
    percentage: 30
  }
};
exports.CircleProgress = CircleProgress;
