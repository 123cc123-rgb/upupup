"use strict";
const CarKeyboard = {
  // 车牌号键盘
  carKeyboard: {
    random: false
  }
};
exports.CarKeyboard = CarKeyboard;
