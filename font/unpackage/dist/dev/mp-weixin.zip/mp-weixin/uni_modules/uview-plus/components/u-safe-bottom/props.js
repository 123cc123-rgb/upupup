"use strict";
const uni_modules_uviewPlus_libs_vue = require("../../libs/vue.js");
require("../../libs/config/config.js");
require("../u-datetime-picker/datetimePicker.js");
require("../u-icon/icon.js");
require("../u-link/link.js");
require("../u-loading-icon/loadingIcon.js");
require("../u-navbar/navbar.js");
const props = uni_modules_uviewPlus_libs_vue.defineMixin({
  props: {}
});
exports.props = props;
