"use strict";
const _imports_0$1 = "/static/logo.svg";
const _imports_0 = "/static/set.svg";
exports._imports_0 = _imports_0$1;
exports._imports_0$1 = _imports_0;
