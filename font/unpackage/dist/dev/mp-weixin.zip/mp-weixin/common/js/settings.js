"use strict";
const base_url = "http://211.144.114.133:8500/index";
exports.base_url = base_url;
