"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const common_vendor = require("./common/vendor.js");
const uni_modules_uviewPlus_index = require("./uni_modules/uview-plus/index.js");
if (!Math) {
  "./pages/index/index.js";
  "./pages/login/index.js";
  "./pages/tabs/tab2.js";
  "./pages/tabs/talk.js";
  "./pages/tabs/mine.js";
  "./pages/tab2_desc/tab1.js";
  "./pages/tab2_desc/tab2.js";
  "./pages/tab2_desc/tab3.js";
  "./pages/talk/fabu.js";
  "./pages/test/index.js";
  "./pages/tab_list/list1.js";
  "./pages/tab_list/list2.js";
  "./pages/tab_list/list3.js";
  "./pages/desc/tab1.js";
  "./pages/desc/tab2.js";
  "./pages/desc/tab3.js";
  "./pages/mine/talk.js";
  "./pages/tabs/desc.js";
}
const _sfc_main = {
  onLaunch: function() {
    console.log("App Launch");
  },
  onShow: function() {
    console.log("App Show");
  },
  onHide: function() {
    console.log("App Hide");
  }
};
function createApp() {
  const app = common_vendor.createSSRApp(_sfc_main);
  app.use(uni_modules_uviewPlus_index.uviewPlus);
  return {
    app
  };
}
createApp().app.mount("#app");
exports.createApp = createApp;
