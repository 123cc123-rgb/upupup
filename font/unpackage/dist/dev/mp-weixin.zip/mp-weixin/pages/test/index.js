"use strict";
const common_vendor = require("../../common/vendor.js");
if (!Array) {
  const _easycom_up_upload2 = common_vendor.resolveComponent("up-upload");
  _easycom_up_upload2();
}
const _easycom_up_upload = () => "../../uni_modules/uview-plus/components/u-upload/u-upload.js";
if (!Math) {
  _easycom_up_upload();
}
const _sfc_main = {
  __name: "index",
  setup(__props) {
    const fileList1 = common_vendor.ref([]);
    const deletePic = (event) => {
      fileList1.value.splice(event.index, 1);
    };
    const afterRead = (event) => {
      let lists = [].concat(event.file);
      let fileListLen = fileList1.value.length;
      lists.map((item) => {
        fileList1.value.push({
          ...item
        });
      });
      for (let i = 0; i < lists.length; i++) {
        let item = fileList1.value[fileListLen];
        fileList1.value.splice(fileListLen, 1, {
          ...item,
          status: "success"
        });
        fileListLen++;
      }
    };
    return (_ctx, _cache) => {
      return {
        a: common_vendor.o(afterRead),
        b: common_vendor.o(deletePic),
        c: common_vendor.p({
          fileList: fileList1.value,
          name: "1",
          maxCount: 1
        }),
        d: common_vendor.gei(_ctx, "")
      };
    };
  }
};
wx.createPage(_sfc_main);
